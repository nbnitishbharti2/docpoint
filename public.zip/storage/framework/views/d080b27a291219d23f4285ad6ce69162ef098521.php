<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-header">
    <div class="row">
        <div class="col-sm-12">
        <div class="user-grp-container">
            <h3 class="page-title">Reviews</h3>
             
       </div>
            <ul class="breadcrumb">
            </ul>
        </div>
    </div>
</div>
<div class="flash-message">
    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(Session::has('alert-' . $msg)): ?>
    <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?></p>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="datatable table table-hover table-center mb-0">
                        <thead>
                            <tr>
                                <th>Doctor name</th>
                                <th>Patent Name</th>
                                <th>Rate</th>
                                <th>Title </th>
                                <th>Description</th>
                                <th>Action</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($value->doctor->name); ?></td>
                                <td><?php echo e($value->patient->name); ?></td>
                                <td><?php echo e($value->rate); ?></td>
                                <td><?php echo e($value->review_title); ?></td>
                                <td><?php echo e($value->review_desc); ?></td>
                                <td>
                                    <?php if($value->status==0): ?>
                                    <a class="btn btn-success" href="<?php echo e(route('change-review',['id'=>$value->id,'status'=>1])); ?>">Approve</a>
                                    <a class="btn btn-danger" href="<?php echo e(route('change-review',['id'=>$value->id,'status'=>2])); ?>">Reject</a>
                                    <?php elseif($value->status==1): ?>
                                        Approved
                                    <?php elseif($value->status==2): ?>
                                        Rejected
                                    <?php endif; ?>
                                </td>
                               
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>			
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/Review/index.blade.php ENDPATH**/ ?>