<?php $__env->startSection('content'); ?>

<div class="flash-message">
    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(Session::has('alert-' . $msg)): ?>
    <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?></p>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="datatable table table-hover table-center mb-0">
                        <thead>
                            <tr>
                                <th>Locality Name</th>
                                <th>Pincode</th>
                                <th>Active</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($locality->name); ?></td>
                                <td><?php echo e($locality->pincode); ?></td>
                                 <td> <div class="status-toggle">
                                            <input type="checkbox" id="status_<?php echo e($locality->id); ?>" data-id = "<?php echo e($locality->id); ?>" class="location check" <?php echo e(($locality->active == '1')? 'checked': ''); ?>>
                                            <label for="status_<?php echo e($locality->id); ?>" class="checktoggle">checkbox</label>
                                        </div></td>
                                        <td>
                                             <a class="btn-sm btn btn-info" title="Edit" href="<?php echo e(route('locality.edit',['id'=>$locality->id])); ?>"><i class="fa fa-pencil"></i></a>
                                             <button class="btn-sm btn btn-danger" title="Delete" onclick="confirm_location_delete(<?php echo e($locality->id); ?>)"><i class="fa fa-trash"></i></button></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>			
</div>


<!-- /.delete confirmation modal -->
<div class="modal fade" id="modal-location-delete">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Delete Locality</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to Delete?</p>
        </div>
        <div class="modal-footer">
            <a href="<?php echo e(url('/location-delete/11')); ?>" id="delete-location" class="btn btn-danger">Delete</a>
            <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<script>
    var change_location_status = "<?php echo e(route('change.location.status')); ?>";
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/Locality/index.blade.php ENDPATH**/ ?>