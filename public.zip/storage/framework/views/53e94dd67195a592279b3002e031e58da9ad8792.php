<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-header">
    <div class="row">
        <div class="col-sm-12">
            <div class="user-grp-container">
                <h3 class="page-title">Reviews</h3>
            </div>
            <ul class="breadcrumb"></ul>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="datatable table table-hover table-center mb-0" id="review_table">
                        <thead>
                            <tr>
                                <th>Doctor name</th>
                                <th>Patent Name</th>
                                <th>Rate</th>
                                <th style="width: 55% !important;">Description</th>
                                <th>Action</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($value->doctor->name); ?></td>
                                    <td><?php echo e($value->user->name); ?></td>
                                    <td><?php echo e($value->rate); ?></td>
                                    <td><?php echo e($value->review_desc); ?></td>
                                    <td style="width: 55% !important;">
                                        <?php if($value->status == 'New'): ?>
                                            <a class="btn btn-success" href="<?php echo e(route('change-review',['id'=>$value->id,'status'=> 'Approved'])); ?>" title="Approve"><i class="fa fa-check" aria-hidden="true"></i>
                                            </a>
                                            <a class="btn btn-danger" href="<?php echo e(route('change-review',['id'=>$value->id,'status'=> 'Rejected'])); ?>" title="Reject"><i class="fa fa-times"></i>
                                            </a>
                                        <?php elseif($value->status == 'Approved'): ?>
                                            Approved
                                        <?php elseif($value->status == 'Rejected'): ?>
                                            Rejected
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>			
</div>
<?php $__env->stopSection(); ?>
<style>
    table#review_table{
        table-layout:fixed;
    }     
</style>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/review/index.blade.php ENDPATH**/ ?>