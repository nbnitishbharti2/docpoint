<div class="sidebar" id="sidebar">
	<div class="sidebar-inner slimscroll">
		<div id="sidebar-menu" class="sidebar-menu">
			<ul>
				<li class="active"><a href="<?php echo e(route('dashboard')); ?>"><i class="fe fe-home"></i> <span>Dashboard</span></a></li>
				<li><a href="<?php echo e(route('review')); ?>"><i class="fe fe-layout"></i> <span>Manage Review</span></a></li>
				<li><a href="<?php echo e(route('doctor.holiday', ['doctor_id' => Auth::user()->doctors->id])); ?>"><i class="fa fa-hand-o-left"></i><span>Holiday</span></a></li>
				<li><a href="<?php echo e(route('appointment.slots')); ?>"><i class="fe fe-layout"></i> <span>Appoinment Slots</span></a></li>
				<li><a href="<?php echo e(route('manage.appointment')); ?>"><i class="fe fe-calendar"></i> <span>Manage Appointments</span></a></li>
			</ul>
		</div>
	</div>
</div><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/Backend/doc_left_nav.blade.php ENDPATH**/ ?>