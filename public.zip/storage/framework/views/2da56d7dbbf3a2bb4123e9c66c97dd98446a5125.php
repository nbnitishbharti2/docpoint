<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-header">
    <div class="row">
        <div class="col-sm-12">
            <div class="user-grp-container">
                <h3 class="page-title">&nbsp;</h3>
                <?php if($premium_charge): ?>
                    <a href="<?php echo e(route('premium.charge.delete', $doctor_id)); ?>">Remove Premium Charge</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Premium Charge Settings </h4>
            </div>
            <div class="card-body">
                <form method = "POST" id="premium_charges" action = "<?php echo e(route('update.premium.charge', $doctor_id)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Amount*</label>
                        <div class="col-md-10">
                            <input name ="amount" required type="text" class="form-control" id="amount" value="<?php echo e((old('amount') ? old('amount') : $premium_charge->amount??'')); ?>">
                            <?php if ($errors->has('amount')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('amount'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-md-2">No of Patient*</label>
                        <div class="col-md-10">
                            <input name ="no_of_patient" required type="number" class="form-control" id="no_of_patient" value="<?php echo e((old('no_of_patient') ? old('no_of_patient') : $premium_charge->no_of_patient??'')); ?>">
                            <?php if ($errors->has('no_of_patient')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('no_of_patient'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Premium Patient*</label>
                        <div class="col-md-10">
                            <input name ="premium_patient" required type="number" class="form-control" id="premium_patient" value="<?php echo e((old('premium_patient') ? old('premium_patient') : $premium_charge->premium_patient??'')); ?>">
                            <?php if ($errors->has('premium_patient')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('premium_patient'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="text-right">
                        <a href="<?php echo e(route('doctor.index')); ?>" class="btn btn-danger">Back</a>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script  src="<?php echo e(asset('public/admin/assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/Premium-charge/index.blade.php ENDPATH**/ ?>