<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Add Appoinment Slot</h4>
            </div>
            <div class="card-body">
                <form method ="POST" enctype='multipart/form-data' id="appointment-slot-form" action="<?php echo e(route('appointment.slots.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Start Date*</label>
                        <div class="col-md-4"> 
                            <input name ="start_date" required type="date" min="<?php echo e(date('Y-m-d')); ?>" class="form-control" id="start_date" value="">
                            <?php if ($errors->has('start_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('start_date'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <label class="col-form-label col-md-2">End Date*</label>
                        <div class="col-md-4"> 
                            <input name ="end_date" required type="date" min="<?php echo e(date('Y-m-d')); ?>" class="form-control" id="end_date" value="<?php echo e(old('end_date')); ?>">
                            <?php if ($errors->has('end_date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('end_date'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Start time*</label>
                        <div class="col-md-4"> 
                            <input name ="start_time" required type="time" class="form-control" id="start_time" value="<?php echo e(old('start_time')); ?>">
                            <?php if ($errors->has('start_time')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('start_time'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <label class="col-form-label col-md-2">End Time*</label>
                        <div class="col-md-4"> 
                            <input name ="end_time" required type="time" class="form-control" id="end_time" value="<?php echo e(old('end_time')); ?>">
                            <?php if ($errors->has('end_time')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('end_time'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Interval (In Minutes)*</label>
                        <div class="col-md-4"> 
                            <input name ="interval" type="number" class="form-control" id="interval" value="<?php echo e(old('interval')); ?>">
                            <?php if ($errors->has('interval')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('interval'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        <label class="col-form-label col-md-2">On Day</label>
                        <div class="col-md-4"> 
                            <div class="weekDays-selector">
                                <input type="checkbox" id="weekday-mon" name="days[0]" value="Monday" class="weekday" />
                                <label for="weekday-mon">M</label>
                                <input type="checkbox" id="weekday-tue" name="days[1]" value="Tuesday" class="weekday" />
                                <label for="weekday-tue">T</label>
                                <input type="checkbox" id="weekday-wed" name="days[2]" value="Wednesday" class="weekday" />
                                <label for="weekday-wed">W</label>
                                <input type="checkbox" id="weekday-thu" name="days[3]" value="Thrusday" class="weekday" />
                                <label for="weekday-thu">T</label>
                                <input type="checkbox" id="weekday-fri" name="days[4]" value="Friday" class="weekday" />
                                <label for="weekday-fri">F</label>
                                <input type="checkbox" id="weekday-sat" name="days[5]" value="Saturday" class="weekday" />
                                <label for="weekday-sat">S</label>
                                <input type="checkbox" id="weekday-sun" name="days[6]" value="Sunday" class="weekday" />
                                <label for="weekday-sun">S</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Appointment Type*</label>
                        <div class="col-md-4 pt-8">
                            <input type="radio" name="appointment_type" id="appointment_type_physical" value="Physical" <?php echo e((old('appointment_type') == "Physical" || old('appointment_type') == null) ? "checked" : ''); ?>> 
                            <label for="appointment_type_physical">Physical</label>
                            <input type="radio" name="appointment_type" id="appointment_type_video" value="Video">
                            <label for="appointment_type_video">Video</label>
                            <?php if ($errors->has('appointment_type')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('appointment_type'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script  src="<?php echo e(asset('public/admin/assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/AppointmentSlots/add.blade.php ENDPATH**/ ?>