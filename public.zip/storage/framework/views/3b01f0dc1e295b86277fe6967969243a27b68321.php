<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Add Holiday</h4>
            </div>
            <div class="card-body">
                <form method = "POST" action = "<?php echo e(route('store.holiday')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Date*</label>
                        <div class="col-md-10">
                            <input name ="date" required type="text" class="form-control" id="date" value="<?php echo e(old('date')); ?>">
                            <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                    </div>
                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script  src="<?php echo e(asset('public/admin/assets/js/custom.js')); ?>"></script>
<script>
$(function(){
    $('#date').datepicker({
        format: 'dd-mm-yyyy',
        orientation: "bottom"
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/holiday/add.blade.php ENDPATH**/ ?>