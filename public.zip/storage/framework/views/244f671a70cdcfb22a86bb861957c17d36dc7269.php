<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Edit Appoinment Slot</h4>
            </div>
            <div class="card-body">
                <form method ="POST" enctype='multipart/form-data' id="speciality-form" action="<?php echo e(route('appointment.slots.update', ['id'=>$data->id])); ?>">
                    <?php echo csrf_field(); ?>
                       
                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Slot time*</label>
                        <div class="col-md-2">
                            <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                            <input name ="slot_time" required type="time" class="form-control" id="slot_time" value="<?php echo e(old('slot_time', $data->slot_time)); ?>">
                            <?php if ($errors->has('slot_time')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('slot_time'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                     </div>
                   
                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script  src="<?php echo e(asset('public/admin/assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/AppointmentSlots/edit.blade.php ENDPATH**/ ?>