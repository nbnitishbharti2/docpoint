<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="datatable table table-hover table-center mb-0">
                        <thead>
                            <tr>
                                <th>Speciality Name</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <h2 class="table-avatar">
                                        <a href="#" class="avatar avatar-sm mr-2">
                                            <img class="avatar-img rounded-circle" src="<?php echo e(($speciality->pic && file_exists('public/storage/images/specialities/'.$speciality->pic)) ? asset('public/storage/images/specialities/'.$speciality->pic) : asset('public/storage/images/specialities/speciality-icon.png')); ?>" alt="<?php echo e($speciality->spec_name); ?>">
                                        </a>
                                        <a href="#"><?php echo $speciality->spec_name; ?></a>
                                    </h2>
                                </td>
                                <td>
                                    <div class="status-toggle">
                                        <input type="checkbox" id="status_<?php echo $speciality->id; ?>" data-id = "<?php echo $speciality->id; ?>" class="speciality check" <?php echo e(($speciality->status == 'Active')? 'checked': ''); ?>>
                                        <label for="status_<?php echo $speciality->id; ?>" class="checktoggle">checkbox</label>
                                    </div>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('Speciality.edit', ['id' => $speciality->id])); ?>" title="Edit Speciality" class="btn-sm btn btn-primary"><i class="fa fa-pencil"></i></a>
                                    <button class="btn-sm btn btn-danger" title="Delete" onclick="confirm_speciality_delete(<?php echo e($speciality->id); ?>)"><i class="fa fa-trash"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>			
</div>
<!-- /.delete confirmation modal -->
<div class="modal fade" id="modal-speciality-delete">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Delete Speciality</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to Delete?</p>
        </div>
        <div class="modal-footer">
            <a href="<?php echo e(url('/speciality-delete/11')); ?>" id="delete-speciality" class="btn btn-danger">Delete</a>
            <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.End delete confirmation modal -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    var change_speciality_status = "<?php echo e(route('change.speciality.status')); ?>";
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/Speciality/index.blade.php ENDPATH**/ ?>