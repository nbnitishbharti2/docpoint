<?php $__env->startSection('title', 'MyDocPoint | Register Doctor'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="margin-bottom: 30px;">
                <div class="card-header"><?php echo e(__('Doctor Register')); ?></div>
                <div class="card-body">
                    <form method="POST" id="doctor-registration" action="<?php echo e(route('create.user')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row registraion-form-input">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Name')); ?></label>
                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                <?php if($errors->has('name')): ?>
                                    <div class="error"><?php echo e($errors->first('name')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row registraion-form-input">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>
                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                                <?php if($errors->has('email')): ?>
                                    <div class="error"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                         <div class="form-group row registraion-form-input">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Mobile No.')); ?></label>
                            <div class="col-md-6">
                                <input id="mobile" type="text" onkeypress="return onlyNumberKey(event)" maxlength="10" minlength="10" class="form-control <?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="mobile" value="<?php echo e(old('mobile')); ?>" required autocomplete="mobile">
                                <?php if($errors->has('mobile')): ?>
                                    <div class="error"><?php echo e($errors->first('mobile')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row registraion-form-input">
                            <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>
                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="new-password">
                                <?php if($errors->has('password')): ?>
                                    <div class="error"><?php echo e($errors->first('password')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row registraion-form-input">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>
                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary register">
                                    <?php echo e(__('Register')); ?>

                                </button>
                                 &nbsp;&nbsp;<a href="<?php echo e(Route('doctor.login')); ?>">Login</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/frontend/doctor/registration.blade.php ENDPATH**/ ?>