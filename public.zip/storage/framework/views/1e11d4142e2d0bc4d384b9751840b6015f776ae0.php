<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="datatable table table-hover table-center mb-0">
                        <thead>
                            <tr>
                                <th>Doctor Name</th>
                                <th>Speciality</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>Sponsored</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <h2 class="table-avatar">
                                            <a href="<?php echo e(route('doctor.profile', ['id' => $doctor->id])); ?>" class="avatar avatar-sm mr-2">
                                                <img class="avatar-img rounded-circle" src="<?php echo e(($doctor->pic && file_exists('public/storage/images/doctor/'.$doctor->pic)) ? asset('public/storage/images/doctor/'.$doctor->pic) : asset('public/files/doctor/profile/doctor-icon.png')); ?>" alt="Doctor Image">
                                            </a>
                                            <a href="<?php echo e(route('doctor.profile', ['id' => $doctor->id])); ?>"><?php echo e($doctor->name); ?></a>
                                        </h2>
                                    </td>
                                    <td><?php echo e($doctor->speciality->spec_name); ?></td>
                                    <td><?php echo e($doctor->mobile); ?></td>
                                    <td><?php echo e($doctor->email); ?></td>
                                    <td>
                                        <div class="status-toggle">
                                            <input type="checkbox" id="status_<?php echo e($doctor->id); ?>" data-id = "<?php echo e($doctor->id); ?>" class="doctor check" <?php echo e(($doctor->status == 'Active')? 'checked': ''); ?>>
                                            <label for="status_<?php echo e($doctor->id); ?>" class="checktoggle">checkbox</label>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="status-toggle">
                                            <input type="checkbox" id="sponsored_<?php echo e($doctor->id); ?>" data-id = "<?php echo e($doctor->id); ?>" class="sponsored check" <?php echo e(($doctor->sponsored == 'Yes')? 'checked': ''); ?>>
                                            <label for="sponsored_<?php echo e($doctor->id); ?>" class="checktoggle">checkbox</label>
                                        </div>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('doctor.edit', ['id' => $doctor->id])); ?>" title="Edit" class="btn-sm btn btn-primary"><i class="fa fa-pencil"></i></a>
                                        <a href="<?php echo e(route('log.history', ['user_id' => $doctor->user_id])); ?>" title="Log History" class="btn-sm btn btn-primary"><i class="fa fa-history"></i></a>
                                        <button class="btn-sm btn btn-danger" title="Delete" onclick="confirm_doctor_delete(<?php echo e($doctor->id); ?>)"><i class="fa fa-trash"></i></button>
                                        <a href="<?php echo e(route('review', ['doctor_id' => $doctor->id])); ?>" title="Reviews" class="btn-sm btn btn-primary"><i class="fa fa-star"></i></a>
                                        <?php if($doctor->sponsored == "Yes"): ?>
                                            <a href="<?php echo e(route('premium.charge', ['doctor_id' => $doctor->id])); ?>" title="Premium Settings" class="btn-sm btn btn-success"><i class="fa fa-cog"></i></a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- /.delete confirmation modal -->
<div class="modal fade" id="modal-doctor-delete">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Delete Doctor</h4>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to Delete?</p>
        </div>
        <div class="modal-footer">
            <a href="<?php echo e(url('/doctor-delete/11')); ?>" id="delete-doctor" class="btn btn-danger">Delete</a>
            <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        </div>
      </div>
      <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    var change_doctor_status = "<?php echo e(route('change.doctor.status')); ?>";
    var change_doctor_sponsored_status = "<?php echo e(route('change.doctor.sponsored.status')); ?>";
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/Doctor/index.blade.php ENDPATH**/ ?>