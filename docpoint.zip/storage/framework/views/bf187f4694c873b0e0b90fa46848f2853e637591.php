<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Edit Doctor</h4>
                </div>
                <div class="card-body">
					<form method="POST" enctype='multipart/form-data' id="doctor-form" action="<?php echo e(route('doctor.update', ['id' => $id])); ?>">
						<?php echo csrf_field(); ?>
						<div class="form-group row">
							<label class="col-form-label col-md-2">Full Name*</label>
							<div class="col-md-10">
								<input type="hidden" name="user_id" value="<?php echo e($docDetails->user_id); ?>">
								<input name="name" type="text" class="form-control" id="name" value="<?php echo e(old('name', $docDetails->name)); ?>">
								<?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-form-label col-md-2">Email*</label>
							<div class="col-md-10">
								<input name="email" type="email" class="form-control" value="<?php echo e(old('email', $docDetails->email)); ?>">
								<?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>

						<div class="form-group row">
							<label class="col-form-label col-md-2">Specialty*</label>
							<div class="col-md-10">
								<select name ="speciality" class="form-control" value="<?php echo e(old('speciality')); ?>">
									<option>Select Specialty</option>
									<?php $__currentLoopData = $specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($speciality->id); ?>" <?php echo e(($docDetails->speciality_id == $speciality->id ? "selected":"")); ?>> <?php echo e($speciality->spec_name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<?php if ($errors->has('speciality')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('speciality'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>

						<div class="form-group row">
							<label class="col-form-label col-md-2">Mobile Number*</label>
							<div class="col-md-10">
								<input name="mobile" type="text" class="form-control" value="<?php echo e(old('mobile', $docDetails->mobile)); ?>">
								<?php if ($errors->has('mobile')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-form-label col-md-2">Phone Number</label>
							<div class="col-md-10">
								<input name="phone" type="text" class="form-control" value="<?php echo e(old('phone', $docDetails->phone)); ?>">
								<?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>

						<div class="form-group row">
							<label class="col-form-label col-md-2">Alternate Number</label>
							<div class="col-md-10">
								<input name="alt_moblie" type="text" class="form-control" value="<?php echo e(old('alt_moblie', $docDetails->alt_moblie)); ?>">
								<?php if ($errors->has('alt_moblie')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('alt_moblie'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>

						<div class="form-group row">
							<label class="col-form-label col-md-2">Fax Number</label>
							<div class="col-md-10">
								<input name="fax" type="text" class="form-control" value="<?php echo e(old('fax', $docDetails->fax)); ?>">
								<?php if ($errors->has('fax')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('fax'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-form-label col-md-2">Gender*</label>
							<div class="col-md-10">
								<select name ="gender" class="form-control">
									<option disabled="" selected="">Select Gender</option>
									<?php $__currentLoopData = $genders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($gender->id); ?>" <?php echo e(($docDetails->gender_id == $gender->id ? "selected":"")); ?>> <?php echo e($gender->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<?php if ($errors->has('gender')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('gender'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-form-label col-md-2">Choose Profile Pic</label>
							<div class="col-md-10">
								<input name='pic' class="form-control" type="file">
								<?php if ($errors->has('pic')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('pic'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-form-label col-md-2">About</label>
							<div class="col-md-10">
								<textarea name="about" rows="5" cols="5" class="form-control"
									placeholder="Enter text here"><?php echo e(old('about', $docDetails->about)); ?></textarea>
								<?php if ($errors->has('about')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('about'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>

						<div class="form-group row">
							<label class="col-form-label col-md-2">Country</label>
							<div class="col-md-10">
								<select name ="country" id="country" class="form-control">
									<option>Select Country</option>
									<?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($country->id); ?>" <?php echo e(($docDetails->country_id == $country->id ? "selected":"")); ?>><?php echo e($country->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<?php if ($errors->has('country')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('country'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-form-label col-md-2">State</label>
							<div class="col-md-10">
								<select name ="state" id="state" class="form-control">
									<option>Select States</option>
									<?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($state->id); ?>" <?php echo e(($docDetails->state_id == $state->id ? "selected":"")); ?>><?php echo e($state->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<?php if ($errors->has('state')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('state'); ?>
								<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
	
						<div class="form-group row">
							<label class="col-form-label col-md-2">City</label>
							<div class="col-md-10">
								<select name ="city" id="city" class="form-control">
									<option>Select City</option>
									<?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($city->id); ?>" <?php echo e(($docDetails->city_id == $city->id ? "selected":"")); ?>><?php echo e($city->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
								<?php if ($errors->has('city')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('city'); ?>
								<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-form-label col-md-2">Address*</label>
							<div class="col-md-10">
								<textarea name="address" rows="5" cols="5" class="form-control"
									placeholder="Enter text here"><?php echo e(old('address', $docDetails->address)); ?></textarea>
								<?php if ($errors->has('address')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('address'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>

						<div class="form-group row">
							<label class="col-form-label col-md-2">Pincode</label>
							<div class="col-md-10">
								<input name="zip" type="text" class="form-control" value="<?php echo e(old('zip', $docDetails->zip)); ?>">
								<?php if ($errors->has('zip')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('zip'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
						

						<div class="form-group row">
							<label class="col-form-label col-md-2">Latitude</label>
							<div class="col-md-10">
								<input name="lat" type="text" class="form-control" value="<?php echo e(old('lat', $docDetails->latitude)); ?>">
								<?php if ($errors->has('lat')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lat'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>

						<div class="form-group row">
							<label class="col-form-label col-md-2">Longitude</label>
							<div class="col-md-10">
								<input name="long" type="text" class="form-control" value="<?php echo e(old('long', $docDetails->longitude)); ?>">
								<?php if ($errors->has('long')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('long'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>

						<div class="form-group row">
							<label class="col-form-label col-md-2">Website</label>
							<div class="col-md-10">
								<input name="website" type="text" class="form-control"
									value="<?php echo e(old('website', $docDetails->website)); ?>">
								<?php if ($errors->has('website')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('website'); ?>
									<span class="text-danger"><?php echo e($message); ?></span>
								<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
						</div>
						<div class="form-group row">
							<label class="col-form-label col-md-2">Status</label>
							<div class="col-md-10">
								<div class="checkbox">
									<label>
										<input name="status" type="checkbox" <?php echo e(($docDetails->status === 'Active')?"checked":''); ?>>
									</label>
								</div>
							</div>
						</div>
						<div class="text-right">
							<button type="submit" class="btn btn-primary">Submit</button>
						</div>
					</form>
				</div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
	var get_state = "<?php echo e(route('get.country.state')); ?>";
	var get_city = "<?php echo e(route('get.state.city')); ?>";
</script>
<script  src="<?php echo e(URL::asset('public/admin/assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/Doctor/edit.blade.php ENDPATH**/ ?>