<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="page-header">
    <div class="row">
        <div class="col-sm-12">
            <div class="user-grp-container">
                <h3 class="page-title">Manage Appointments</h3>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="datatable table table-hover table-center mb-0">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Name</th>
                                <th>Reason</th>
                                <th>Patient Type</th>
                                <th>Appointment Type</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(date("d-m-Y", strtotime($value->appointment_date))); ?></td>
                                    <td><?php echo e(date("h:i A", strtotime($value->appointment_slot->slot_time))); ?></td>
                                    <td><?php echo e(Str::ucfirst($value->user->name)); ?></td>
                                    <td><?php echo e(Str::ucfirst($value->reason->name)); ?></td>
                                    <td><?php echo e(Str::ucfirst($value->patient_type)); ?></td>
                                    <td><?php echo e(Str::ucfirst($value->appointment_type)); ?></td>
                                    <td> 
                                        <?php echo e(Str::ucfirst($value->status)); ?>

                                    </td>
                                    <td>
                                        <?php if($value->status != 'Canceled'): ?>
                                            <div class="status-toggle">
                                                <input type="checkbox" title="Change Status" id="status_<?php echo e($value->id); ?>" data-id = "<?php echo e($value->id); ?>" class="appointment check" <?php echo e(($value->status == 'Active')? 'checked': ''); ?>>
                                                <label for="status_<?php echo e($value->id); ?>" class="checktoggle">checkbox</label>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>			
</div>
<script>
    var change_appoinment_status = "<?php echo e(route('change.appointment.status')); ?>";
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/appointments/index.blade.php ENDPATH**/ ?>