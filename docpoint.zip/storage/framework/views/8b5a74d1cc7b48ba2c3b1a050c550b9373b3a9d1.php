<div class="row">
    <div class="col-sm-12">
        <div class="tab-content donation-layout">
            <?php if(Session::has('error')): ?>
            <div class="alert alert-danger alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <?php echo e(Session::pull('error')); ?>

            </div>
            <?php endif; ?>
            <?php if(Session::has('message')): ?>
            <div class="alert alert-success alert-dismissible" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <?php echo e(Session::pull('message')); ?>

            </div>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/layouts/message.blade.php ENDPATH**/ ?>