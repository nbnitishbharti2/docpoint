<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Edit Country</h4>
            </div>
            <div class="card-body">
                <form method ="POST" enctype='multipart/form-data' id="speciality-form" action="<?php echo e(route('country.edit', ['country_id'=>$data->id])); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-form-label col-md-2">Name*</label>
                        <div class="col-md-10">
                            <input type="hidden" name="id" value="<?php echo e($data->id); ?>">
                            <input name ="name" required type="text" class="form-control" id="name" value="<?php echo e(old('name', $data->name)); ?>">
                            <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                     </div>
                     <div class="form-group row">
                        <label class="col-form-label col-md-2">IOS Alpha 2*</label>
                        <div class="col-md-4">
                            <input name ="iso_alpha_2" required type="text" class="form-control" id="iso_alpha_2" value="<?php echo e(old('iso_alpha_2', $data->iso_alpha_2)); ?>">
                            <?php if ($errors->has('iso_alpha_2')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('iso_alpha_2'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                      
                        <label class="col-form-label col-md-2">IOS Alpha 3*</label>
                        <div class="col-md-4">
                            <input name ="iso_alpha_3" required type="text" class="form-control" id="iso_alpha_3" value="<?php echo e(old('iso_alpha_3', $data->iso_alpha_3)); ?>">
                            <?php if ($errors->has('iso_alpha_3')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('iso_alpha_3'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                     </div>
                     <div class="form-group row">
                        <label class="col-form-label col-md-2">Currency Code*</label>
                        <div class="col-md-4">
                            <input name ="currency_code" required type="text" class="form-control" id="currency_code" value="<?php echo e(old('currency_code', $data->currency_code)); ?>">
                            <?php if ($errors->has('currency_code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('currency_code'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                      
                        <label class="col-form-label col-md-2">Dailing Code*</label>
                        <div class="col-md-4">
                            <input name ="dailing_code" required type="text" class="form-control" id="dailing_code" value="<?php echo e(old('dailing_code', $data->dailing_code)); ?>">
                            <?php if ($errors->has('dailing_code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('dailing_code'); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                     </div> 
                    <div class="text-right">
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script  src="<?php echo e(asset('public/admin/assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\docpoint\resources\views/Country/edit.blade.php ENDPATH**/ ?>